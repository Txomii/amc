#ifndef COMERCIALTP_H
#define COMERCIALTP_H
#include "ComercialTP.h"
#include "Fecha.h"
#include "Comercial.h"
#include <iostream>
#include <cstring>

using namespace std;

class ComercialTP : public Comercial
{
    private:
        int horas;

    public:
        ComercialTP(char* nom, Fecha f , int h);
        bool operator==(const ComercialTP& ctp);
        friend ostream& operator<<(ostream& os, const ComercialTP& ctp);

        float nomina() const {return Comercial::nomina() + horas*10 ;}

        //no uso el constructor de copia, el destructor y el operador asignacion
        //porque no trabajo con memoria dinamica por lo que el que genera el proio compliador me vale





};

#endif // COMERCIALTP_H
