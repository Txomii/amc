#ifndef FECHA_H
#define FECHA_H


class Fecha
{
    private:
        int dia, mes, anio;
    public:
        Fecha(int d, int m, int a);
        int getDia() const {return dia; }
        int getMes() const {return mes;}
        int getAnio() const {return anio;}

};

#endif // FECHA_H
