#ifndef COMERCIAL_H
#define COMERCIAL_H
#include "Fecha.h"
#include <iostream>
#include <cstring>

using namespace std;

class Comercial
{
    private:
        static int n;
        int cod_comercial;
        Fecha contrato;
        char* nombre;
        static float base;

    public:
        Comercial(char* nom, Fecha f);
        virtual ~Comercial();
        float nomina() const {return 3* base * 1.25+ 32.5;}

        float getBase() const {return base;}

        static void setBase(float b){
            if(b < 150){
                b = 150;
            }
            Comercial::base = b;
        }

        Comercial(const Comercial& c);
        Comercial& operator= (const Comercial& c);
        bool operator==(const Comercial& c);

        const char* getNombre() const {return nombre;}
        Fecha getFecha() const {return contrato;}
        int getCodComercial() const {return cod_comercial;}

        friend ostream& operator<<(ostream& os, const Comercial& c);

};

#endif // COMERCIAL_H
