#include "Fecha.h"

Fecha::Fecha(int d, int m, int a)
{
    dia = d; mes=m; anio=a;
}

