#include <iostream>
#include "Fecha.h"
#include "Comercial.h"
#include "ComercialTP.h"

using namespace std;

int main()
{
    const Fecha f1(1,1,2000);

    Comercial c1("Jose" , f1) , c2(c1);
    cout << c1 << c2;

    cout << c1.getBase() << endl;
    c1.setBase(100);
    cout << c1.getBase() << endl;
    cout << c1 << c2;

    if(c1 == c2){ cout << "son exactamente iguales"<<endl;}
    else {cout << "No son exactamente iguales"<<endl;}

    c2 = c1;
    cout << c1 << c2;
    if(c1 == c2){ cout << "son exactamente iguales"<<endl;}
    else {cout << "No son exactamente iguales"<<endl;}

    cout<< "--------------------------------------------------" << endl;

    ComercialTP ctp1("Jose" , f1 , 31) , ctp2(ctp1);
    cout << ctp1 << ctp2;

    if(ctp1 == ctp2){ cout << "son exactamente iguales"<<endl;}
    else {cout << "No son exactamente iguales"<<endl;}

    ctp2 = ctp1;
    cout << ctp1 << ctp2;
    if(ctp1 == ctp2){ cout << "son exactamente iguales"<<endl;}
    else {cout << "No son exactamente iguales"<<endl;}

    return 0;
}
